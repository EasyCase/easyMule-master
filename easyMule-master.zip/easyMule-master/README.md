编译说明（推荐使用Visual Studio 2013）
1.将rcdll.dll复制到Visual Studio 2013安装目录的VC\bin目录中。（这是为了使用能在vista下显示的图标）
2.打开easyMule_Libs.sln，执行“生成解决方案”。（easyMule_Libs.sln里所包含的是easyMule所依赖的库文件。）
3.打开easyMule.sln编译即可。

------------------------------------------------------------------------------------------------------------


电驴服务器列表(eMule server list)：
http://gruk.org/list.php
ed2k://|server|27.152.28.252|4242|/

这个是我维护的easyMule版本，由于不断的修改，可能会离原来的版本越来越远。


详情可参见：http://blog.csdn.net/analogous_love/article/details/74627971


=========================================================================
Tips：
如果您在使用这份代码的过程中遇到任何问题，可以通过我的微信公众号『easyserverdev』与我取得联系，获得帮助，或者加入QQ技术群进行交流：49114021。


Compiling instruction (recommend to use Visual Studio 2013)
1.Copy rcdll.dll to VC7\bin under the installation directory of Visual Studio 2013.(in order to use special icons under Vista)
2.Open easyMule_Libs.sln and execute 'build solution'.(easyMule_Libs.sln contains libraries which easyMule depends on)
3.Open easyMule.sln and compile it.

This is a version of easyMule I maintained, so this version will be farther and farther from the original version.

See details at site： http://blog.csdn.net/analogous_love/article/details/74627971

You can contact with me by WeChat Official Accounts: 『easyserverdev』 or joining my QQ Group: 49114021 if you met any questions when using this source code.
