
#include "SingleInst.h"

extern CSingleInst	theLoaderSingleInst;

extern const UINT UWM_ARE_YOU_LOADER;

#define LOADER_GUID _T("{C3BE6A7B-2D9A-4033-A300-43A728A689DA}")
#define LOADERHELPERWND_CLASSNAME		_T("Ed2kLoaderHelperWnd")

#define UM_STOP_MESSAGE					(WM_APP + 1329)
#define UM_COPYDATACODE_ED2KLINK		(WM_APP + 1560)
